#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\src\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\AT\Downloads\workspace-01a14ebe-bcc6-7f17-a412-c59e1184a915\photo_recovery_restore"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=C:\Users\AT\Downloads\workspace-01a14ebe-bcc6-7f17-a412-c59e1184a915\photo_recovery_restore\ios\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
