import '../../domain/media_candidate.dart';
import 'existing_media_exclusion_models.dart';
import 'existing_media_index.dart';

class ExistingMediaExclusionEngine {
  const ExistingMediaExclusionEngine();

  ExistingMediaDecision evaluate(
    MediaCandidate candidate,
    ExistingMediaIndex index,
  ) {
    final uriKey = ExistingMediaKeys.uri(
      candidate.contentUri ?? candidate.documentUri,
    );
    final uriMatches = uriKey == null ? null : index.findByUri(uriKey);
    if (uriMatches != null && uriMatches.isNotEmpty) {
      return _exactMatchDecision(candidate, uriMatches.first);
    }

    final platformKey = ExistingMediaKeys.platformIdentity(
      mediaStoreId: candidate.mediaStoreId,
      storageVolumeName: candidate.storageVolumeName,
    );
    final platformMatches = platformKey == null
        ? null
        : index.findByPlatformIdentity(platformKey);
    if (platformMatches != null && platformMatches.isNotEmpty) {
      return _exactMatchDecision(candidate, platformMatches.first);
    }

    final storageLocationKey = ExistingMediaKeys.storageLocation(
      storageVolumeName: candidate.storageVolumeName,
      relativeLocation: candidate.relativeLocation,
      displayName: candidate.displayName,
      byteSize: candidate.byteSize,
    );
    final storageLocationMatches = storageLocationKey == null
        ? null
        : index.findByStorageLocation(storageLocationKey);
    if (storageLocationMatches != null) {
      if (storageLocationMatches.length == 1) {
        return _exactMatchDecision(candidate, storageLocationMatches.single);
      }
      if (storageLocationMatches.isNotEmpty) {
        return const ExistingMediaDecision.uncertainIdentity();
      }
    }

    final compositeKey = ExistingMediaKeys.compositeMetadata(
      displayName: candidate.displayName,
      mimeType: candidate.mimeType,
      byteSize: candidate.byteSize,
      width: candidate.width,
      height: candidate.height,
      relativeLocation: candidate.relativeLocation,
      bucketName: candidate.bucketName,
    );
    final compositeMatches = compositeKey == null
        ? null
        : index
              .findByCompositeMetadata(compositeKey)
              ?.where((reference) {
                final candidateVolume = ExistingMediaKeys.lowerText(
                  candidate.storageVolumeName,
                );
                final existingVolume = ExistingMediaKeys.lowerText(
                  reference.metadata?.storageVolumeName ??
                      reference.record.storageVolumeName,
                );
                return candidateVolume == null ||
                    existingVolume == null ||
                    candidateVolume == existingVolume;
              })
              .toList(growable: false);
    if (compositeMatches != null) {
      if (compositeMatches.length == 1) {
        return _exactMatchDecision(candidate, compositeMatches.single);
      }
      if (compositeMatches.isNotEmpty) {
        return const ExistingMediaDecision.uncertainIdentity();
      }
    }

    if (_hasWeakOverlap(candidate, index)) {
      return const ExistingMediaDecision.uncertainIdentity();
    }
    return const ExistingMediaDecision.noExistingMatch();
  }

  ExistingMediaDecision _exactMatchDecision(
    MediaCandidate candidate,
    ExistingMediaReference reference,
  ) {
    final evidence = candidate.discoveryEvidence;
    final independentlyInspectedArtifact =
        (candidate.filePath != null || candidate.contentUri != null) &&
        evidence.detectedFormat != null &&
        (evidence.isCacheLike ||
            evidence.isThumbnailLike ||
            evidence.isTrashLike) &&
        ExistingMediaKeys.isRecoveryArtifactLocation(
          candidate.relativeLocation ?? candidate.bucketName,
        ) &&
        ExistingMediaKeys.isRecoveryArtifactLocation(
          reference.metadata?.relativePath ??
              reference.record.relativePath ??
              reference.metadata?.bucketName ??
              reference.record.bucketName,
        );
    return independentlyInspectedArtifact
        ? const ExistingMediaDecision.noExistingMatch()
        : ExistingMediaDecision.definitelyExisting(reference);
  }

  bool _hasWeakOverlap(MediaCandidate candidate, ExistingMediaIndex index) {
    final fileName = ExistingMediaKeys.text(candidate.displayName);
    if (fileName != null && index.containsFileName(fileName)) return true;

    final dimensions = ExistingMediaKeys.dimensions(
      candidate.width,
      candidate.height,
    );
    if (dimensions != null && index.containsDimensions(dimensions)) return true;

    for (final timestamp in [
      candidate.takenAt,
      candidate.modifiedAt,
      candidate.createdAt,
    ]) {
      if (timestamp != null &&
          index.containsTimestamp(timestamp.millisecondsSinceEpoch)) {
        return true;
      }
    }
    return false;
  }
}
